#ifndef TYPES
#define TYPES

typedef struct {
    int x;
    int y;
} Vector2i;

typedef struct {
    int x;
    int y;
    int w;
    int h;
} Vector4i;

#endif